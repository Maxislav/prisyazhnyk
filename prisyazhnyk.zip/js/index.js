$(document).ready(function(){
	$('.post__article').scrollNav({
		headlineText: '',
		topLinkText: 'Home',
		//fixedMargin: 140,
		scrollOffset: 180,
	});

})
